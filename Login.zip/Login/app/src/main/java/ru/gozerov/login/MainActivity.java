package ru.gozerov.login;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

import ru.gozerov.login.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    private static final String login = "login";
    private static final String password = "password";

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (login.equals(binding.loginEditText.getText().toString()) &&
                password.equals(binding.passwordEditText.getText().toString())) {
                    Snackbar
                            .make(binding.getRoot(), "Верно", Snackbar.LENGTH_SHORT)
                            .setBackgroundTint(Color.GREEN)
                            .setTextColor(Color.BLACK)
                            .show();
                }
                else {
                    Snackbar
                            .make(binding.getRoot(), "Вы ошиблись в логине или пароле", Snackbar.LENGTH_SHORT)
                            .setBackgroundTint(Color.RED)
                            .show();
                    binding.loginEditText.setText("");
                    binding.passwordEditText.setText("");
                }
            }
        });
    }
}